# Arena Nova — protótipo demonstrativo

Site responsivo em um único arquivo HTML, feito para testar a experiência pelo celular.

## O que funciona
- Layout responsivo para celular e computador.
- Navegação por âncoras.
- Filtros das partidas fictícias.
- Seleção visual de cotações de demonstração.
- Botões da área de jogos com avisos demonstrativos.
- Sem login, backend, depósitos, saques, pagamentos ou apostas reais.

## Abrir no celular
1. Extraia `arenanova-demo.zip` usando o gerenciador de arquivos do celular.
2. Abra `index.html` com um navegador. Dependendo do Android, pode ser necessário usar um editor de código ou hospedar o arquivo para visualizar corretamente.

## Publicar gratuitamente pelo celular com GitHub Pages
1. Entre em https://github.com/ e crie uma conta ou faça login.
2. Crie um repositório público, por exemplo `arenanova-demo`.
3. Toque em **Add file** → **Upload files** e envie `index.html`.
4. Confirme em **Commit changes**.
5. Abra **Settings** → **Pages**.
6. Em **Build and deployment**, selecione **Deploy from a branch**; escolha `main` e `/ (root)` e salve.
7. Aguarde a publicação. O GitHub mostrará o endereço do site na própria página Pages.

O caminho dos menus pode variar um pouco no celular. Não inclua senhas, documentos ou dados pessoais no repositório.

## Personalização
Edite `index.html`. O nome “Arena Nova”, as cores e as partidas de demonstração podem ser alterados. Os dados atuais são fictícios.

## Aviso
Este é um protótipo visual. Não é uma plataforma de apostas e não deve ser apresentado como serviço de jogo com dinheiro real. Verifique a legislação aplicável antes de qualquer uso comercial.
